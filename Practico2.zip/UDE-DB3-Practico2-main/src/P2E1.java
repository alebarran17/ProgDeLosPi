import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class P2E1
{
	public static void main (String[] args)
	{
		try
		{
			/* primer programa de prueba para ejemplo de acceso a MySQL desde Java */
			/* accede a una base de datos de MySQL llamada Prueba que contiene una tabla llamada Personas */
			/* dentro de dicha tabla hay una columna llamada nombre */
			
			Properties prop = new Properties();
			String nomArch = "config/conexion.properties";
			prop.load (new FileInputStream (nomArch));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("urlEj2CDB");
			String user = prop.getProperty("user");
			String passw = prop.getProperty("passw");
			

			/* 1. cargo dinamicamente el driver de MySQL */
			Class.forName(driver);

			/* 2. una vez cargado el driver, me conecto con la base de datos */
			Connection con = DriverManager.getConnection(url, user, passw);

			/* CREACION DE BASE DE DATOS */
			//String insert = "CREATE DATABASE Escuela";
			//PreparedStatement pstmt = con.prepareStatement(insert);
			
			/* CREACION DE TABLAS */
		//String insert = "CREATE TABLE Personas (cedula INT, nombre VARCHAR(45), apellido VARCHAR(45)); ";
//		String insert = "CREATE TABLE Maestras (cedula INT, grupo VARCHAR(45)); ";
//			String insert = "CREATE TABLE Alumnos (cedula INT, cedulaMaestra INT); ";
			
			/* SE AGREGAN PY Y FK */
//			String insert = "ALTER TABLE Personas ADD CONSTRAINT PK_Persona PRIMARY KEY (cedula); ";
//		String insert = "ALTER TABLE Maestras ADD CONSTRAINT PK_PerMaestra PRIMARY KEY (cedula); ";
//			String insert = "ALTER TABLE Maestras ADD CONSTRAINT FOREIGN KEY (cedula) REFERENCES Personas(cedula); ";
//			String insert = "ALTER TABLE Alumnos ADD CONSTRAINT PK_PerAlumno PRIMARY KEY (cedula); ";
//		String insert = "ALTER TABLE Alumnos ADD CONSTRAINT FOREIGN KEY (cedula) REFERENCES Personas(cedula); ";
			String insert = "ALTER TABLE Alumnos ADD CONSTRAINT FOREIGN KEY (cedulaMaestra) REFERENCES Maestras(cedula); ";


			PreparedStatement pstmt = con.prepareStatement(insert);			
					

			/* 4. ejecuto la sentencia de insercion y cierro el PreparedStatement */
			int cant = pstmt.executeUpdate();
			pstmt.close();
			System.out.print("Resultado de " + insert + ": ");
			System.out.println(cant + " filas afectadas");


			/* 7. por ultimo, cierro la conexion con la base de datos */
			con.close();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}	
	}
}
