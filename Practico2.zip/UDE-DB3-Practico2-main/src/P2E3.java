import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class P2E3
{
	public static void main (String[] args)
	{
		try
		{
			/* primer programa de prueba para ejemplo de acceso a MySQL desde Java */
			/* accede a una base de datos de MySQL llamada Prueba que contiene una tabla llamada Personas */
			/* dentro de dicha tabla hay una columna llamada nombre */
			
			Properties prop = new Properties();
			String nomArch = "config/conexion.properties";
			prop.load (new FileInputStream (nomArch));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("urlEj2CDB");
			String user = prop.getProperty("user");
			String passw = prop.getProperty("passw");
			
			/* 1. cargo dinamicamente el driver de MySQL */
			Class.forName(driver);

			/* 2. una vez cargado el driver, me conecto con la base de datos */
			Connection con = DriverManager.getConnection(url, user, passw);
			
			
			System.out.println("Ingrese comando sql: ");
			InputStreamReader is = new InputStreamReader (System.in);
			BufferedReader br = new BufferedReader (is);
			String consulta = br.readLine();
			
			while (!consulta.equals("exit")) {
				// EJECUTO COMANDO
				PreparedStatement pstmt = con.prepareStatement(consulta);
				
				/* 4. ejecuto la sentencia de insercion y cierro el PreparedStatement */
				int cant = pstmt.executeUpdate();
				pstmt.close();
				System.out.print("Consulta " + consulta + ": ");
				System.out.println(cant + " filas afectadas");
				
				System.out.println("Ingrese comando sql: ");
				consulta = br.readLine();
			}

			System.out.println("Hasta la próxima");
			
			/* 7. por ultimo, cierro la conexion con la base de datos */
			con.close();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}	
	}
}
