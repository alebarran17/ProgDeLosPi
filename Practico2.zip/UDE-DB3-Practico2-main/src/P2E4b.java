import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Properties;

public class P2E4b {
	public static void main (String[] args)
	{
		try
		{
			/* primer programa de prueba para ejemplo de acceso a MySQL desde Java */
			/* accede a una base de datos de MySQL llamada Prueba que contiene una tabla llamada Personas */
			/* dentro de dicha tabla hay una columna llamada nombre */
			
			Properties prop = new Properties();
			String nomArch = "config/conexion.properties";
			prop.load (new FileInputStream (nomArch));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("urlEj2CDB");
			String user = prop.getProperty("user");
			String passw = prop.getProperty("passw");
			
			/* 1. cargo dinamicamente el driver de MySQL */
			Class.forName(driver);

			/* 2. una vez cargado el driver, me conecto con la base de datos */
			Connection con = DriverManager.getConnection(url, user, passw);
			
			//1er consulta
			String consulta1 = "SELECT M.cedula FROM maestras M;";
			
				// EJECUTO COMANDO
			    PreparedStatement pstmt = con.prepareStatement(consulta1);
				
				/* 4. ejecuto la sentencia de insercion y cierro el PreparedStatement */
				//pstmt.executeQuery();
				//pstmt.close();
				
				ResultSet rs = pstmt.executeQuery(consulta1);
				LinkedList<Integer> listaCedulas = new LinkedList<>();
				while (rs.next())
				{
					listaCedulas.add(rs.getInt("cedula"));
				}
				rs.close();
				//2da 
				String consulta2 = "SELECT count(*) AS cant FROM maestras M JOIN alumnos A ON M.cedula = A.cedulaMaestra WHERE M.cedula = ?;";
				int ciMaestraMas = -1, aux = -1;
				for(var key: listaCedulas) {
					
					pstmt = con.prepareStatement(consulta2);
					pstmt.setInt(1, key);
					ResultSet rs2 = pstmt.executeQuery(consulta2);
					
					if(rs2.next()) {
						aux = rs2.getInt("cant");
						ciMaestraMas = ciMaestraMas < aux ? aux : ciMaestraMas;
					}
					rs2.close();
				}
				
				//3ra
				String consulta3 = "SELECT P.nombre, P.apellido FROM Personas P WHERE cedula = ?;";
				
				pstmt = con.prepareStatement(consulta3);
				pstmt.setInt(1, ciMaestraMas);
				ResultSet rs3 = pstmt.executeQuery(consulta3);
				
				if(rs3.next()) {
					System.out.println("Nombre = " + rs3.getString("nombre").trim());
					System.out.println("Apellido = " + rs3.getString("apellido").trim());
				}
				rs3.close();
				pstmt.close();
				/*una recorrida hash:
				  for(var key: listaCedulas.keySet()) {
					pstmt.setInt(1, key);
					ResultSet rs2 = pstmt.executeQuery(consulta2);	
					
					if(rs2.next()) {
						listaCedulas.replace(key, rs2.getInt("cant"));
					}
				}*/
				
			
				
				
				
			
			/* 7. por ultimo, cierro la conexion con la base de datos */
			con.close();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}	
	}
}
