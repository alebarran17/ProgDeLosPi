import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class P2E4 {
	public static void main (String[] args)
	{
		try
		{
			/* primer programa de prueba para ejemplo de acceso a MySQL desde Java */
			/* accede a una base de datos de MySQL llamada Prueba que contiene una tabla llamada Personas */
			/* dentro de dicha tabla hay una columna llamada nombre */
			
			Properties prop = new Properties();
			String nomArch = "config/conexion.properties";
			prop.load (new FileInputStream (nomArch));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("urlEj2CDB");
			String user = prop.getProperty("user");
			String passw = prop.getProperty("passw");
			
			/* 1. cargo dinamicamente el driver de MySQL */
			Class.forName(driver);

			/* 2. una vez cargado el driver, me conecto con la base de datos */
			Connection con = DriverManager.getConnection(url, user, passw);
			
			
			String consulta = "SELECT M.cedula, P.nombre, P.apellido, count(*) FROM maestras M JOIN alumnos A ON M.cedula = A.cedulaMaestra JOIN personas P ON M.cedula = P.cedula GROUP BY M.cedula, P.nombre, P.apellido ORDER BY 4 desc LIMIT 1;";
			
				// EJECUTO COMANDO
			    PreparedStatement pstmt = con.prepareStatement(consulta);
				
				/* 4. ejecuto la sentencia de insercion y cierro el PreparedStatement */
				//pstmt.executeQuery();
				//pstmt.close();
				
				ResultSet rs = pstmt.executeQuery();
				System.out.println("Resultado de " + consulta);
				if (rs.next())
				{
					System.out.println("Cedula = " + rs.getString("cedula").trim());
					System.out.println("Nombre = " + rs.getString("nombre").trim());
					System.out.println("Apellido = " + rs.getString("apellido").trim());
				}
				rs.close();
				pstmt.close();
			
			/* 7. por ultimo, cierro la conexion con la base de datos */
			con.close();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}	
	}
}

